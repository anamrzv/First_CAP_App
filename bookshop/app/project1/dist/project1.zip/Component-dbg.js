sap.ui.define(['sap/suite/ui/generic/template/lib/AppComponent'], function (AppComponent) {
    return AppComponent.extend('project1.Component', {
      metadata: {
        manifest: 'json'
      }
    });
  });