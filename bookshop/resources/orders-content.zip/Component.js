sap.ui.define(["sap/fe/core/AppComponent"], ac => ac.extend("orders.Component", {
    metadata:{ manifest:'json' }
}))

// sap.ui.define (["sap/ui/core/UIComponent"], ui5 => ui5.extend("bookshop.Component", {
//     metadata: { manifest: "json" }
// }))
// sap.ui.define (["sap/ui/generic/app/AppComponent"], ui5 => ui5.extend("bookshop.Component", {
//     metadata: { manifest: "json" }
// }))

// jQuery.sap.declare("bookshop.Component");
// sap.ui.getCore().loadLibrary("sap.ui.generic.app");
// jQuery.sap.require("sap.ui.generic.app.AppComponent");

// sap.ui.generic.app.AppComponent.extend("bookshop.Component", {
// 	metadata: {
// 		manifest: "json"
// 	}
// });

/* eslint no-undef:0 */